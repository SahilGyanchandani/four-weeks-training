﻿namespace BlogSystemApp
{
    public class ModelBuilder
    {
    }
}