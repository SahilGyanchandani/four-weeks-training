﻿namespace BlogSystemApp
{
    public class DbcontextClass
    {
    }
}
