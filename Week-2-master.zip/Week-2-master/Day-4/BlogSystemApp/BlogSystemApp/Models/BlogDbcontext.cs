﻿namespace BlogSystemApp.Models
{
    public class BlogDbcontext
    {
    }
}
