﻿namespace BlogSystemApp.Models
{
    public class Class
    {
    }
}
