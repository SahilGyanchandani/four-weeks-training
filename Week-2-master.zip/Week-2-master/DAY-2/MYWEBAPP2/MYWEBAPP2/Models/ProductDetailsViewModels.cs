﻿namespace MYWEBAPP2.Models
{
    public class ProductDetailsViewModel
    {
        public Product Product { get; set; }
        public string DisplayMessage { get; set; }
        
  }