using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ASP.NET_Core_web_Application.Pages
{
    public class HelloModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
